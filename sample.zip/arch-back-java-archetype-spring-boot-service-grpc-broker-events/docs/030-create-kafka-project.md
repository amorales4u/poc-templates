# Crear proyecto Kafka Consumer y producer

Como ejemplo Crearemos un proyecto con los siguientes prompts:

```yaml
---
answers:
    project:
        value: Contract
    suffix:
        value: Service Consumer
    group-prefix:
        value: com.cardif.bra
    persistence: 
        value: H2
    event-module: 
        value: Kafka Event Consumer
    broker-server: 
        value: localhost
    broker-port: 
        value: 9092
    service-port: 
        value: 9010


```

### Crer poyecto consumidor en el puerto 9011

```shell
mkdir -p ~/dev/demo-events/
cd ~/dev/demo-events/
rm -r contract-service-consumer
# Create consumer service named Contract and Set range ports to 9010:
archetect render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/contract-service-consumer/
mvn clean install
cd ~/dev/demo-events/contract-service-consumer/contract-service-consumer-server
mvn spring-boot:run
```

### Crer poyecto productor en el puerto 9021

```shell

# Create producer service named Contract and Set range ports to 9020:
cd ~/dev/demo-events/
rm -r contract-service-producer
archetect render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/contract-service-producer/
mvn clean install
cd ~/dev/demo-events/contract-service-producer/contract-service-producer-server
mvn spring-boot:run
```

### Enviar mensajes al puerto 9021 y verificar log del servicio en el puerto 9011

```shell

# Test with cURL

curl --request PUT \
  --url http://localhost:9021/ \
  --header 'Content-Type: application/json' \
  --data '{
  "message": "The first Kafka sent Message"
}'

# or test in PowerShell

$headers=@{}
$headers.Add("Content-Type", "application/json")
$response = Invoke-RestMethod -Uri 'http://localhost:9021/' -Method PUT -Headers $headers -ContentType 'application/json' -Body '{
  "message": "The first Kafka sent Message"
}'

```

---
| [Principal](../README.md) <br/> | Anterior <br/>[Archetect](020-archetect.md) | Siguiente<br/> [Crear proyectos RabbitMQ](040-create-rabbitmq-project.md) |
|---------------------------------|---------------------------------------------|---------------------------------------------------------------------------|
