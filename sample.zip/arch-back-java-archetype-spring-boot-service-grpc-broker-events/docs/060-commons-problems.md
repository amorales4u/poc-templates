# Problemas Comunes al generar proyectos con Archetect

At create/render project with **archetect** the must common error show as:`Rendering IO Error: The system cannot find the path specified. (os error 3)`
, this error caused by a nonexistent variable, check de Jinja tags with the generated variables in archetype.yml

When you render a project and have that error, the problem is in the last file or directory rendered.

For correct errors en templates you need:

1) Cloning the template project:

```shell
git clone https://gitlab.palo-it.net/hive-tech/architecture/archetect/customer-templates/femsa/b2b/arch-back-java-archetype-spring-boot-service-grpc.git
```

2) archetect render in local mode :
```shell
archetect render ./arch-back-java-archetype-spring-boot-service-grpc
```
or
render with a high verbosity label:
```shell
archetect render -vvv ./arch-back-java-archetype-spring-boot-service-grpc
```

with -vvv  you see a log with more information, and archetect show log like this:

```shell
Project Name: User
Project Type: [DomainGateway]
GroupId Prefix: [com.b2b] com.palo.it
Domain / Kubernetes Namespace: [user]
Service Port Range Start: [8080]
archetect: Setting variable answer "management-port"="{{ service-port + 1 }}"
archetect: Setting variable answer "debug-port"="{{ service-port + 9 }}"
Integrate default service? [n]
Jfrog repository url: [https://nexus.digitalb2b.dev]
Jfrog repository relaese name: [b2b-libs-release]
Jfrog repository snapshot name: [b2b-libs-snapshot]
Url docker registry: [690003025816.dkr.ecr.us-east-1.amazonaws.com]
sonar url: [https://sonarqube.digitalb2b.dev]
Url docker registry image: [690003025816.dkr.ecr.us-east-1.amazonaws.com/User-gateway:1.$BITBUCKET_BUILD_NUMBER]
archetect: Setting variable answer "ProjectTitle"="{{ project | title_case }} {{ suffix | title_case }}"
archetect: Setting variable answer "ProjectPrefix"="{{ project | pascal_case }}"
archetect: Setting variable answer "projectPrefix"="{{ project | camel_case }}"
archetect: Setting variable answer "project_prefix"="{{ project | snake_case }}"
archetect: Setting variable answer "project-prefix"="{{ project | train_case }}"
archetect: Setting variable answer "PROJECT_PREFIX"="{{ project | constant_case }}"
archetect: Setting variable answer "ProjectSuffix"="{{ suffix | pascal_case }}"
archetect: Setting variable answer "project_suffix"="{{ suffix | snake_case }}"
archetect: Setting variable answer "project-suffix"="{{ suffix | train_case }}"
archetect: Setting variable answer "root_package"="{{ group-prefix }}.{{ project | package_case }}.{{ suffix | package_case }}"
archetect: Setting variable answer "root_directory"="{{ root_package | package_to_directory }}"
archetect: Setting variable answer "artifact_id"="{{ project_prefix }}_{{ project_suffix }}"
archetect: Setting variable answer "artifact-id"="{{ project-prefix }}-{{ project-suffix }}"
archetect: Setting variable answer "client-artifact-id"="{{ project-prefix }}-service"
archetect: Setting variable answer "client_root_package"="{{ group-prefix }}.{{ project | package_case }}.service"
archetect: Setting variable answer "group-id"="{{ group-prefix }}.{{ artifact-id }}"
archetect: Setting variable answer "property-prefix"="{{ artifact-id }}"
archetect: Rendering   ".\\user-domain-gateway"
archetect: Preserving  ".\\user-domain-gateway\\.gitignore"
archetect: Preserving  ".\\user-domain-gateway\\bitbucket-pipelines.yml"
archetect: Preserving  ".\\user-domain-gateway\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\support"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\support\\Converter.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCore.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreConfig.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\support"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\support\\ConverterTest.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreConfigTest.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreTest.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources\\schema"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources\\schema\\schema.graphqls"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\util"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\util\\Projections.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayBaseIT.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayCoreTest.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayIntegrationTestConfig.java"
archetect: Rendering IO Error: The system cannot find the path specified. (os error 3)
```

3) Check last file/directory.
4) Check Jinja tags are defined in archetype.xml
5) Try render again.


If you find errors, have ideas or contributions for this template you are welcome to improve this project :-)
Checkout open tickets on the [project planning board](https://gitlab.com/nirvana4/platform/archetypes/archetype-java-service-spring-boot/-/boards)




---
| [Principal](../README.md) <br/> | Anterior <br/>[General testing](050-general-testing.md) |
|---------------------------------|---------------------------------------------------------|
