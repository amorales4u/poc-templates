# General Testing


**httpYac** provides a system to provide a simple way to create, execute, and store information about HTTP requests even to gRPC calls.

Install in Visual Studio Code, you can se a complete guide in [httpYac](https://httpyac.github.io/guide/)

![httpYac.png](../httpYac.png)


open test-client.http for test your http and gRPC new Services.
```http request
###

@http_host=http://localhost:{{ management-port }}
@gRPC_host=localhost:{{ service-port }}
@gRPC_proto_file=./{{ artifact-id }}-grpc/src/main/proto/{{ project-prefix }}-{{ project-suffix}}.proto

@project_name={{ project-prefix }}
@project_service_name={{ project-prefix }}-{{ project-suffix}}

###
GET {{http_host}}/actuator

###

GET {{http_host}}/actuator/health

###

GET {{http_host}}/actuator/info

###

proto < {{gRPC_proto_file}}
GRPC {{gRPC_host}}/{{project_service_name}}/Get{{ ProjectPrefix | pluralize }}
{ 
    "startPage": 0,
    "pageSize": 10

}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Get{{project_name}}
{ 
    "id": "893ccc03-3c47-492d-b388-a21d642c063f"
}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Update{{project_name}}
{ 
    "id": {
        "value":"893ccc03-3c47-492d-b388-a21d642c063f"
    },
    "name": "John Doe"

}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Create{{project_name}}
{
    "employee": {
        "id": {
            "value": "893ccc03-3c47-492d-b388-a21d642c063f"
        },
        "name": "Juan Perez"
    }
}

###

```

---
| [Principal](../README.md) <br/> | Anterior <br/>[Crear proyecto RabbitMQ](030-create-rabbitmq-project.md) | Siguiente <br/>[Problemas Comunes al generar proyectos con Archetect](060-commons-problems.md) | 
|---------------------------------|-------------------------------------------------------------------------|------------------------------------------------------------------------------------------------|

