# Preparacion del ambiente de desarrollo

el ambiente de desarrollo debe contar con:
* JDK 17
* Maven 3.x

Antes de iniciar es necesario que se compilen los siguientes artefactos:

1. parent-dependencies: <small>Contiene las versiones de los productos a utilizar</small>
1. common-events-kafka: <small>Integra funcionalidades de consumidor y productor de eventos
 Kafka</small>
1. common-events-rabbitmq: <small>Integra funcionalidades de consumidor y productor de eventos
   RabbitMQ</small>

   
## Compilacion de parent-dependencies:

```shell

mkdir -p ~/dev/architecture/commons/libs/java/command-events

cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/archetect/customer-templates/femsa/b2b/parent-dependencies.git

cd parent-dependencies

git checkout HT-63/Integracion-de-kafka

mvn clean install

```
## Compilacion de common-events-kafka:

```shell
mkdir -p ~/dev/architecture/commons/libs/java/command-events

cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/common-events-kafka.git

cd common-events-kafka

mvn clean install

```
## Compilacion de common-events-rabbitmq:

```shell
mkdir -p ~/dev/architecture/commons/libs/java/command-events
cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/common-events-rabbitmq.git

cd common-events-rabbitmq

mvn clean install

cd ~/

```

---

| [Principal](../README.md) <br/> | Anterior <br/>[Introduccion](001-introduccion.md) | Siguiente<br/> [Ejecucion de Archetect](020-archetect.md)  |
|---------------------------------|---------------------------------------------------|----------------------------------------------|

