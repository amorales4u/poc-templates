# Introduccion

En este tutorial podra generar proyectos gRPC y Rest con las siguientes funcionalidades:

1. Consumo de Bases de datos:
   2. PostgreSQL
   3. MySQL
   4. H2
   5. MongoDB
   6. Redis
   
1. Eventos:
   1. Productor con Kafka
   1. Consumidor con Kafka
   1. Productor con RabbitMQ
   1. Consumidor con RabbitMQ

Al generar el proyecto se generan los siguientes artefactos:

1. api: <small>Definicion de las funcionalidades u operaciones del proyecto</small>
2. avro: <small>Definicion del model AVRO</small>
3. bom: <small>Bill Of Materials del proyecto</small>
4. client: <small>Cliente para el consumo del servicio desde gRPC, implementa el modulo API</small>
5. core: <small>Servicios SpringBoot que implementan la logica del proyecto, logica de negocio, este podra ser consumido desde el modulo SERVER</small>
6. grpc: </small>Definicion de las operaciones gRPC</small>
7. integration-test: <small>Pruebas integrales</small>
8. persistence: <small>Definicion de Entidades y Repositorios</small>
9. server: <small>Levanta el servidor con SpringBoot asi como el servidor gRPC, contiene el application.yml del proyecto</small>
10. event-kafka-consumer: <small>Contiene el listener de los eventos consumidos desde Kafka</small>
11. event-kafka-producer: <small>Contiene el productor de eventos (Mensajes) enviados (AVRO) al broker de Kafka</small>
12. event-rabbitmq-consumer: <small>Contiene el listener de los eventos consumidos desde RabbitMQ</small>
13. event-rabbitmq-producer: <small>Contiene el productor de eventos (Mensajes) enviados (AVRO) al broker de RabbitMQ</small>

Como apoyo se otorgan los docker compose de los productos a utilizar.
Docker Images:
1. [PostgreSQL](../docker-images/postgres/docker-compose.yml)
1. [MySQL](../docker-images/postgres/docker-compose.yml)
1. [MongoDB](../docker-images/mongodb/docker-compose.yml)
1. [Redis](../docker-images/redis/docker-compose.yml)
1. [Kafka con Schema Registry](../docker-images/kafka-schema-registry/docker-compose.yml)
1. [RabbitMQ](../docker-images/rabbitmq/docker-compose.yml)

Para levantar su docker image usar el siguiente comando:
```shell
docker compose up -d
```
---

| [Principal](../README.md) <br/>                  | Siguiente<br/> [Preparacion de ambiente](010-preparacion-ambiente.md) |
|--------------------------------------------------|-----------------------------------------------------------------------|
