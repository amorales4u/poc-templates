# Archetect

Para la generacion de proyectos basados en este template es necesario
que conozca el uso de 
[Archetect en la guia de confluece](https://paloit.atlassian.net/wiki/spaces/PIK/pages/1977352193/Archetect+code+generator).

Para este template se piden los siguientes parametros:


| Property                         | Description                                                                                                           | Example                                      |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------|----------------------------------------------|
| `Project`                        | Singular General name that represents the service domain that is used to set the entity, service, and RPC stub names. | Employee                                     |
| `Project Type`                   | Singular name Used in conjunction with `project` to set package names.                                                | Service                                      | 
| `GroupId Prefix`                 | Used in conjunction with `project` to set package names.                                                              | com.palo.it                                  |
| `Name Space`                     | Domain / Kubernetes Namespace.                                                                                        | service                                      |
| `Persistence Engine`             | Set the RDBMS to use ( PostgreSQL, MySQL, H2, MongoDB, Redis ).                                                       | H2                                           |
| `Event Module`                   | Set if do you what a Event project type ( Kafka or RabbitMQ, Producer or Consumer ).                                  | No                                           |
| `Service Port Range Start`       | Sets the port used for gRPC traffic                                                                                   | 9010                                         |
| `HTTP Management Port`           | Sets the port used to monitor the application over HTTP                                                               | {{ service-port + 1 }}                       |
| `HTTP server Port`               | Sets the port used to set server HTTP port                                                                            | {{ service-port + 1 }}                       |
| `Developer Database Port`        | Sets the port used to connect to Database selected                                                                    | {{ service-port + 2 }}                       |
| `Remote Debug Port`              | Sets the port used to debug application over HTTP                                                                     | {{ service-port + 9 }}                       |
| `Jfrog repository url`           | Sets the Jfrog repository URL                                                                                         | https://nexus.digitalb2b.dev                 |
| `Jfrog repository relaese name`  | Sets the Jfrog repository release name                                                                                | b2b-libs-release                             |
| `Jfrog repository snapshot name` | Sets the Jfrog repository snapshot name                                                                               | b2b-libs-snapshot                            |
| `Url docker registry`            | Sets URL Docker registry                                                                                              | 690003025816.dkr.ecr.us-east-1.amazonaws.com |
| `sonar url`                      | Sets URL Sonar                                                                                                        | https://sonarqube.digitalb2b.dev             |


Tomando en cuenta los prompts anteriores ya podemos crear nuestro primer proyecto.

En la siguiente seccion se explica.

---
| [Principal](../README.md) <br/> | Anterior <br/>[Preparacion de ambiente](010-preparacion-ambiente.md) | Siguiente<br/> [Crear proyectos Kafka](030-create-kafka-project.md) |
|---------------------------------|----------------------------------------------------------------------|---------------------------------------------------------------------|
