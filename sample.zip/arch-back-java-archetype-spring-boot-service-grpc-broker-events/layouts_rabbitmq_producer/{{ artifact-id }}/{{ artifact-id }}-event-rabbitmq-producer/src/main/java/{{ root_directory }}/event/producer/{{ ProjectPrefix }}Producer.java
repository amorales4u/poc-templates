package {{ root_package }}.event.producer;

import {{ group-prefix }}.{{ namespace }}.model.avro.{{ ProjectPrefix }}Model;
import com.palo.it.event.rabbitmq.producer.EventProducer;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;


@Service
public class {{ ProjectPrefix }}Producer extends EventProducer<{{ ProjectPrefix }}Model,{{ ProjectPrefix }}Model> {

    private final static Logger log = LoggerFactory.getLogger({{ ProjectPrefix }}Producer.class);

    public {{ ProjectPrefix }}Producer(RabbitTemplate rabbitTemplate) {
        super(rabbitTemplate);
    }

    @Override
    public void onSendSuccess({{ ProjectPrefix }}Model result) {
      log.info("Sent {{ ProjectPrefix }}Model:" + result);
    }

    @Override
    public void onSendError({{ ProjectPrefix }}Model result, Throwable ex) {
        log.error("Error AT Send {{ ProjectPrefix }}Model:", ex);
        System.out.println(ex);
    }
}
