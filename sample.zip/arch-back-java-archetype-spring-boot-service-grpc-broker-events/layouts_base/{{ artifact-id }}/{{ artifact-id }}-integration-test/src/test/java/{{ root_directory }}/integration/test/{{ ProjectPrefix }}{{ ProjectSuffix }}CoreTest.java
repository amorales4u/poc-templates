package {{ root_package }}.integration.test;

import {{ root_package }}.grpc.{{ ProjectPrefix }}Dto;
import {{ root_package }}.grpc.Get{{ ProjectPrefix }}Request;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class {{ ProjectPrefix }}{{ ProjectSuffix }}CoreTest extends {{ ProjectPrefix }}{{ ProjectSuffix }}BaseIT{

    //@Test
    public void create{{ ProjectPrefix }}(){
     var createRequest= {{ ProjectPrefix }}Dto.newBuilder().setName("test").build();
        var response=client.create{{ ProjectPrefix }}(createRequest);
        Assertions.assertTrue(response.get{{ ProjectPrefix }}().getId().isInitialized());
    }

    //@Test
    public void find{{ ProjectPrefix }}(){
        var create{{ ProjectPrefix }}= {{ ProjectPrefix }}Dto.newBuilder().setName("test").build();
        var response=client.create{{ ProjectPrefix }}(create{{ ProjectPrefix }});
        var get{{ ProjectPrefix }}Request=Get{{ ProjectPrefix }}Request.newBuilder().setId(response.get{{ ProjectPrefix }}().getId().getValue()).build();
        var get{{ ProjectPrefix }}Response=client.get{{ ProjectPrefix }}(get{{ ProjectPrefix }}Request);
        Assertions.assertTrue(get{{ ProjectPrefix }}Response.has{{ ProjectPrefix }}());
        Assertions.assertTrue(get{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().isInitialized());
    }

}