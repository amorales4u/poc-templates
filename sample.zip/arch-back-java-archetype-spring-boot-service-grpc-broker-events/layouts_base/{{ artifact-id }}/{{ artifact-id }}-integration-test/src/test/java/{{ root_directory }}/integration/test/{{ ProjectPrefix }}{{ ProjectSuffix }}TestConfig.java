package {{ root_package }}.integration.test;

import {{ root_package }}.client.{{ ProjectPrefix }}{{ ProjectSuffix }}Client;
import {{ root_package }}.server.{{ ProjectPrefix }}{{ ProjectSuffix }}Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

@Configuration
public class {{ ProjectPrefix }}{{ ProjectSuffix }}TestConfig {

    @Bean(initMethod = "start", destroyMethod = "stop")
    public {{ ProjectPrefix }}{{ ProjectSuffix }}Server server({% if persistence=='PostgreSQL' %} PostgreSQLContainer container {% endif %}) {
        {% if persistence=='PostgreSQL' %}
        var jdbcUrl = container.getJdbcUrl();
        {% endif %}
        return new {{ ProjectPrefix }}{{ ProjectSuffix }}Server()
        {% if persistence=='PostgreSQL' %}
                .withProperties("spring.datasource.url", jdbcUrl)
                .withProperties("spring.datasource.username", container.getUsername())
                .withProperties("spring.datasource.password", container.getPassword())
                .withProperties("spring.liquibase.url", jdbcUrl)
                .withProperties("spring.liquibase.user", container.getUsername())
                .withProperties("spring.liquibase.password", container.getPassword()){% endif %};
    }
    {% if persistence=='PostgreSQL' %}
    @Bean(initMethod = "start", destroyMethod = "stop")
    public PostgreSQLContainer postgreSQLContainer() {
        return new PostgreSQLContainer(DockerImageName.parse("postgres:latest"));
    }
    {% endif %}

    @Bean
    public {{ ProjectPrefix }}{{ ProjectSuffix }}Client client({{ ProjectPrefix }}{{ ProjectSuffix }}Server server) {
        return {{ ProjectPrefix }}{{ ProjectSuffix }}Client.of("localhost", server.getGrpcPort());
    }

}