package {{ root_package }}.integration.test;

import {{ root_package }}.client.{{ ProjectPrefix }}{{ ProjectSuffix }}Client;
import {{ root_package }}.integration.test.{{ ProjectPrefix }}{{ ProjectSuffix }}TestConfig;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;


//@ExtendWith({SpringExtension.class})
//@ContextConfiguration(classes = { {{ ProjectPrefix }}{{ ProjectSuffix }}TestConfig.class })
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class {{ ProjectPrefix }}{{ ProjectSuffix }}BaseIT {
    //@Autowired
    protected {{ ProjectPrefix }}{{ ProjectSuffix }}Client client;
}