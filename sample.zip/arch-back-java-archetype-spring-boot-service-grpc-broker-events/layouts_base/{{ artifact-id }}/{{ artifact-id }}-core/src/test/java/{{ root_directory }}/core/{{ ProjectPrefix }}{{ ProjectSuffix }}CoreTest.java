package {{ root_package }}.core;

import com.google.protobuf.StringValue;
import {{ root_package }}.grpc.*;
import {{ root_package }}.persistence.entities.{{ ProjectPrefix }}Entity;
import {{ root_package }}.persistence.repositories.{{ ProjectPrefix }}Repository;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class {{ ProjectPrefix }}{{ ProjectSuffix }}CoreTest {

    @MockBean
    static {{ ProjectPrefix }}Repository repository;

    static {{ ProjectPrefix }}Entity g{{ ProjectPrefix }}Entity;

    static UUID gUUID;

    @BeforeAll
    static void setUp(){
        gUUID = UUID.randomUUID();
        g{{ ProjectPrefix }}Entity = new {{ ProjectPrefix }}Entity(gUUID, "{{ ProjectPrefix }}1");
        repository = Mockito.mock({{ ProjectPrefix }}Repository.class);
    }


    @Test
    void test_create{{ ProjectPrefix }}() {
        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

        {{ ProjectPrefix }}Dto v{{ ProjectPrefix }} = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .build();

        Mockito.when(repository.save(Mockito.any()))
                .thenReturn(g{{ ProjectPrefix }}Entity);

        Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.create{{ ProjectPrefix }}(v{{ ProjectPrefix }});

        assertThat(create{{ ProjectPrefix }}Response).isNotNull();
        assertThat(create{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}()).isNotNull();
        int respComp = gUUID.compareTo(UUID.fromString(create{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().getValue()));
        assertThat(respComp).isZero();

    }

    @Test
    void test_get{{ ProjectPrefix }}s() {
            {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);


        Mockito.when(repository.findAll(Mockito.any(Pageable.class)))
                .thenReturn(new PageImpl<>(List.of(g{{ ProjectPrefix }}Entity), PageRequest.of(1, 10),List.of(g{{ ProjectPrefix }}Entity).size()));
        Mockito.when(repository.findAll())
                .thenReturn(List.of(g{{ ProjectPrefix }}Entity));

        Get{{ ProjectPrefix }}sRequest get{{ ProjectPrefix }}sRequest = Get{{ ProjectPrefix }}sRequest.newBuilder()
                .build();


        Get{{ ProjectPrefix }}sResponse get{{ ProjectPrefix }}sResponse = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.get{{ ProjectPrefix }}s(get{{ ProjectPrefix }}sRequest);

        assertThat(get{{ ProjectPrefix }}sResponse).isNotNull();
        assertThat(get{{ ProjectPrefix }}sResponse.get{{ ProjectPrefix }}Count()).isPositive();
        int respComp = gUUID.compareTo(UUID.fromString(get{{ ProjectPrefix }}sResponse.get{{ ProjectPrefix }}(0).getId().getValue()));
        assertThat(respComp).isZero();

    }

    @Test
    void test_get{{ ProjectPrefix }}() {

        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

        Mockito.when(repository.findById(Mockito.any(UUID.class)))
                .thenReturn(Optional.ofNullable(g{{ ProjectPrefix }}Entity));


        Get{{ ProjectPrefix }}Request get{{ ProjectPrefix }}Request = Get{{ ProjectPrefix }}Request.newBuilder()
                .setId(gUUID.toString())
                .build();

        Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.get{{ ProjectPrefix }}(get{{ ProjectPrefix }}Request);

        assertThat(get{{ ProjectPrefix }}Response).isNotNull();
        assertThat(get{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getName()).isEqualTo("{{ ProjectPrefix }}1");
        int respComp = gUUID.compareTo(UUID.fromString(get{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().getValue()));
        assertThat(respComp).isZero();

    }


    @Test
    void test_get{{ ProjectPrefix }}_null() {

        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

        Mockito.when(repository.findById(Mockito.any(UUID.class)))
                .thenReturn(Optional.empty());


        Get{{ ProjectPrefix }}Request get{{ ProjectPrefix }}Request = Get{{ ProjectPrefix }}Request.newBuilder()
                .setId(gUUID.toString())
                .build();

        Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.get{{ ProjectPrefix }}(get{{ ProjectPrefix }}Request);

        assertThat(get{{ ProjectPrefix }}Response).isNull();

    }

    @Test
    void test_update{{ ProjectPrefix }}() {

        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

        {{ ProjectPrefix }}Dto v{{ ProjectPrefix }} = {{ ProjectPrefix }}Dto.newBuilder()
                .setId(StringValue.of(gUUID.toString()))
                .setName("{{ ProjectPrefix }}1")
                .build();
        Mockito.when(repository.findById(Mockito.any(UUID.class)))
                .thenReturn(Optional.ofNullable(g{{ ProjectPrefix }}Entity));

        Mockito.when(repository.save(Mockito.any()))
                .thenReturn(g{{ ProjectPrefix }}Entity);

        Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.update{{ ProjectPrefix }}(v{{ ProjectPrefix }});

        assertThat(update{{ ProjectPrefix }}Response).isNotNull();
        //assertThat(gUUID.compareTo(UUID.fromString(update{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().getValue()))).isEqualTo(0);
    }


    @Test
    void test_update{{ ProjectPrefix }}_without_id() {

        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

        {{ ProjectPrefix }}Dto v{{ ProjectPrefix }} = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .build();
        Mockito.when(repository.findById(Mockito.any(UUID.class)))
                .thenReturn(Optional.ofNullable(g{{ ProjectPrefix }}Entity));

        Mockito.when(repository.save(Mockito.any()))
                .thenReturn(g{{ ProjectPrefix }}Entity);

        Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.update{{ ProjectPrefix }}(v{{ ProjectPrefix }});

        assertThat(update{{ ProjectPrefix }}Response).isNotNull();
        //assertThat(gUUID.compareTo(UUID.fromString(update{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().getValue()))).isEqualTo(0);
    }

    @Test
    void test_update{{ ProjectPrefix }}_without_entity() {

        {{ ProjectPrefix }}{{ ProjectSuffix }}Core v{{ ProjectPrefix }}{{ ProjectSuffix }}Core = new {{ ProjectPrefix }}{{ ProjectSuffix }}Core(repository);

            {{ ProjectPrefix }}Dto v{{ ProjectPrefix }} = {{ ProjectPrefix }}Dto.newBuilder()
                .setId(StringValue.of(gUUID.toString()))
                .setName("{{ ProjectPrefix }}1")
                .build();
        Mockito.when(repository.findById(Mockito.any(UUID.class)))
                .thenReturn(Optional.empty());


        Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}Response = v{{ ProjectPrefix }}{{ ProjectSuffix }}Core.update{{ ProjectPrefix }}(v{{ ProjectPrefix }});

        assertThat(update{{ ProjectPrefix }}Response).isNotNull();
        //assertThat(gUUID.compareTo(UUID.fromString(update{{ ProjectPrefix }}Response.get{{ ProjectPrefix }}().getId().getValue()))).isEqualTo(0);
    }
}