package {{ root_package }}.core.support;

import com.google.protobuf.StringValue;
import {{ root_package }}.grpc.{{ ProjectPrefix }}Dto;
import {{ root_package }}.persistence.entities.{{ ProjectPrefix }}Entity;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

class ConvertersTest {

    @BeforeAll
    static void setUp(){

    }

    //@Test
    //void test_constructors(){
    //}


    @Test
    void test_convert_to_{{ ProjectPrefix }}Dto(){
        {{ ProjectPrefix }}Dto v{{ ProjectPrefix }}Dto = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .setId(StringValue.of(UUID.randomUUID().toString()))
                .build();

        {{ ProjectPrefix }}Entity convert = Converters.convert(v{{ ProjectPrefix }}Dto);

        int respComp = convert.getId().compareTo(UUID.fromString(v{{ ProjectPrefix }}Dto.getId().getValue()));
        assertThat(respComp).isZero();
        assertThat(convert.getName()).isEqualTo(v{{ ProjectPrefix }}Dto.getName());


    }

    @Test
    void test_convert_to_{{ ProjectPrefix }}Dto_Name_Balance(){
        {{ ProjectPrefix }}Dto v{{ ProjectPrefix }}Dto = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .build();

        {{ ProjectPrefix }}Entity convert = Converters.convert(v{{ ProjectPrefix }}Dto);

        assertThat(convert.getName()).isEqualTo(v{{ ProjectPrefix }}Dto.getName());


    }


    @Test
    void test_convert_to_{{ ProjectPrefix }}Entity(){
        {{ ProjectPrefix }}Entity accountEntity = new {{ ProjectPrefix }}Entity();

        accountEntity.setName("{{ ProjectPrefix }}1");
        accountEntity.setId(UUID.randomUUID());

        {{ ProjectPrefix }}Dto convert = Converters.convert(accountEntity);

        int respComp = accountEntity.getId().compareTo(UUID.fromString(convert.getId().getValue()));

        assertThat(respComp).isZero();
        assertThat(convert.getName()).isEqualTo(accountEntity.getName());

    }

    @Test
    void test_convert_to_{{ ProjectPrefix }}Entity_Name_Balance(){
        {{ ProjectPrefix }}Entity accountEntity = new {{ ProjectPrefix }}Entity();

        accountEntity.setName("{{ ProjectPrefix }}1");

        {{ ProjectPrefix }}Dto convert = Converters.convert(accountEntity);


        assertThat(convert.getName()).isEqualTo(accountEntity.getName());

    }


}