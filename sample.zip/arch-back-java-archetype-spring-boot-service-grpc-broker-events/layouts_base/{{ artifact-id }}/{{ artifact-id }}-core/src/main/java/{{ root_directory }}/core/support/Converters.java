package {{ root_package }}.core.support;

import com.google.protobuf.StringValue;
import {{ root_package }}.grpc.{{ ProjectPrefix }}Dto;
import {{ root_package }}.persistence.entities.{{ ProjectPrefix }}Entity;

import java.util.UUID;

public class Converters {

    private Converters(){
        throw new IllegalStateException("Utility class");
    }
    public static {{ ProjectPrefix }}Dto convert({{ ProjectPrefix }}Entity {{ projectPrefix }}Entity) {
        {{ ProjectPrefix }}Dto.Builder builder = {{ ProjectPrefix }}Dto.newBuilder()
                .setName({{ projectPrefix }}Entity.getName());
        if ({{ projectPrefix }}Entity.getId() != null) {
            builder.setId(StringValue.of({{ projectPrefix }}Entity.getId().toString()));
        }
        return builder.build();
    }

    public static {{ ProjectPrefix }}Entity convert({{ ProjectPrefix }}Dto {{ projectPrefix }}) {
        {{ ProjectPrefix }}Entity entity;
        if ({{ projectPrefix }}.hasId()) {
            entity = new {{ ProjectPrefix }}Entity(UUID.fromString({{ projectPrefix }}.getId().getValue()), {{ projectPrefix }}.getName());
        } else {
            entity = new {{ ProjectPrefix }}Entity({{ projectPrefix }}.getName());
        }
        return entity;
    }
}
