package {{ root_package }}.core;

import {{ root_package }}.persistence.{{ ProjectPrefix }}{{ ProjectSuffix }}PersistenceConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan
@Import( {{ ProjectPrefix }}{{ ProjectSuffix }}PersistenceConfig.class )
public class {{ ProjectPrefix }}{{ ProjectSuffix }}CoreConfig {
}
