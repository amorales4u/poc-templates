package {{ root_package }}.core;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import {{ root_package }}.api.{{ ProjectPrefix }}{{ ProjectSuffix }};
import {{ root_package }}.core.support.Converters;
import {{ root_package }}.grpc.*;
import {{ root_package }}.persistence.entities.{{ ProjectPrefix }}Entity;
import {{ root_package }}.persistence.repositories.{{ ProjectPrefix }}Repository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static {{ root_package }}.core.support.Converters.convert;

@Service
public class {{ ProjectPrefix }}{{ ProjectSuffix }}Core implements {{ ProjectPrefix }}{{ ProjectSuffix }} {
    private final {{ ProjectPrefix }}Repository repository;

public {{ ProjectPrefix }}{{ ProjectSuffix }}Core({{ ProjectPrefix }}Repository repository)
    {
        this.repository = repository;
    }

@Override
public Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }}) {
    {{ ProjectPrefix }}Entity savedEntity = repository.save(new {{ ProjectPrefix }}Entity({{ projectPrefix }}.getName()));
    return Create{{ ProjectPrefix }}Response.newBuilder()
            .set{{ ProjectPrefix }}(convert(savedEntity))
            .build();
}

@Override
public Get{{ ProjectPrefix | pluralize }}Response get{{ ProjectPrefix | pluralize }}(Get{{ ProjectPrefix | pluralize }}Request request) {
    int pageSize = Math.min(Math.max(request.getPageSize(), 10), 100);
    Pageable pageable = PageRequest.of(request.getStartPage(), pageSize);
    Page<{{ ProjectPrefix }}Entity> page = repository.findAll(pageable);
    List<{{ ProjectPrefix }}Dto> {{ projectPrefix | pluralize }} = page.stream().map(Converters::convert).collect(Collectors.toList());
    return Get{{ ProjectPrefix | pluralize }}Response.newBuilder()
            .addAll{{ ProjectPrefix }}({{ projectPrefix | pluralize }})
            .setHasNext(page.hasNext())
            .setHasPrevious(page.hasPrevious())
            .setNextPage(page.getPageable().next().getPageNumber())
            .setTotalElements(page.getTotalElements())
            .setTotalPages(page.getTotalPages())
            .build();
}

@Override
public Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}(Get{{ ProjectPrefix }}Request request) {
    Optional<{{ ProjectPrefix }}Entity> response = repository.findById(UUID.fromString(request.getId()));
    if (response.isPresent()) {
        {{ ProjectPrefix }}Entity entity = response.get();
        return Get{{ ProjectPrefix }}Response.newBuilder().set{{ ProjectPrefix }}(convert(entity)).build();
    }
    return null; // TODO: Handle error!
}

@Override
public Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }}) {
    if ({{ projectPrefix }}.hasId()) {
        UUID id = UUID.fromString({{ projectPrefix }}.getId().getValue());
        Optional<{{ ProjectPrefix }}Entity> entity = repository.findById(id);
        if (entity.isPresent()) {
            {{ ProjectPrefix }}Entity {{ projectPrefix }}Entity = entity.get();
            {{ projectPrefix }}Entity.setName({{ projectPrefix }}.getName());
            repository.save({{ projectPrefix }}Entity);
            return Update{{ ProjectPrefix }}Response.getDefaultInstance();
        }
    }
    return Update{{ ProjectPrefix }}Response.getDefaultInstance();
}

}
