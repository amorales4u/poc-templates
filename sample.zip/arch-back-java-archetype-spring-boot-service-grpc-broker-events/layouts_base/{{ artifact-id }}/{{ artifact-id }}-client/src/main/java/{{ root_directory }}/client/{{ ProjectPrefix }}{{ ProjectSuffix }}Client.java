package {{ root_package }}.client;

import io.grpc.ManagedChannelBuilder;
import {{ root_package }}.api.{{ ProjectPrefix }}{{ ProjectSuffix }};
import {{ root_package }}.grpc.*;


public class {{ ProjectPrefix }}{{ ProjectSuffix }}Client implements {{ ProjectPrefix }}{{ ProjectSuffix }}  {

  {{ ProjectPrefix }}{{ ProjectSuffix }}Grpc.{{ ProjectPrefix }}{{ ProjectSuffix }}BlockingStub stub;

    public static {{ ProjectPrefix }}{{ ProjectSuffix }}Client of(String host, int port) {
        return new {{ ProjectPrefix }}{{ ProjectSuffix }}Client(ManagedChannelBuilder.forAddress(host, port).usePlaintext());
    }

    private {{ ProjectPrefix }}{{ ProjectSuffix }}Client(ManagedChannelBuilder<?> channelBuilder) {
        this.stub = {{ ProjectPrefix }}{{ ProjectSuffix }}Grpc.newBlockingStub(channelBuilder.build());
    }

    @Override
    public Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }}) {
        return stub.create{{ ProjectPrefix }}({{ projectPrefix }});
    }

    @Override
    public Get{{ ProjectPrefix | pluralize }}Response get{{ ProjectPrefix | pluralize }}(Get{{ ProjectPrefix | pluralize }}Request request) {
        return stub.get{{ ProjectPrefix | pluralize }}(request);
    }

    @Override
    public Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}(Get{{ ProjectPrefix }}Request request) {
        return stub.get{{ ProjectPrefix }}(request);
    }

    @Override
    public Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }}) {
        return stub.update{{ ProjectPrefix }}({{ projectPrefix }});
    }

}
