package {{ root_package }}.server.controller;

{% if event-module == 'Kafka Event Producer' or event-module == 'RabbitMQ Event Producer' %}
import {{ root_package }}.event.producer.{{ ProjectPrefix }}Producer;
import {{ group-prefix }}.{{ namespace }}.model.avro.{{ ProjectPrefix }}Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.UUID;
{% endif %}

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {

    @GetMapping(path = "/")
    public String root() {
        return "{{ ProjectTitle }}";
    }

{% if event-module == 'Kafka Event Producer' or event-module == 'RabbitMQ Event Producer' %}
    @Autowired
    private {{ ProjectPrefix }}Producer {{ projectPrefix }}ProducerService;
    @PutMapping("/")
    public String send( @RequestBody String message ) {

        {{ ProjectPrefix }}Model {{ projectPrefix }}Model =
            {{ ProjectPrefix }}Model.newBuilder()
                        .setId(UUID.randomUUID().toString() )
                        .setName( message )
                        .build();

        {{ projectPrefix }}ProducerService.sendMessage({{ projectPrefix }}Model, {{ projectPrefix }}Model.getId());

        return {{ projectPrefix }}Model.toString();

    }    
    {% endif %}
}
