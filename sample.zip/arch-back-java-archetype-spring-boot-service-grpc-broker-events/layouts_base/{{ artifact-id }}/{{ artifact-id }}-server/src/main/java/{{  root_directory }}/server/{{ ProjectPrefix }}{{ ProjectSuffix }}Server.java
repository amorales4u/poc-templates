package {{ root_package }}.server;

import org.lognet.springboot.grpc.autoconfigure.GRpcServerProperties;
import org.apache.logging.log4j.util.Strings;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Properties;

@Component
public class {{ ProjectPrefix }}{{ ProjectSuffix }}Server {
  String[] args;
    SpringApplication springApplication;
    Properties overrides;
    private ConfigurableApplicationContext context;


    public {{ ProjectPrefix }}{{ ProjectSuffix }}Server withArguments(String[] args) {
        this.args = args;
        return this;
    }

    public {{ ProjectPrefix }}{{ ProjectSuffix }}Server withProperties(String name, String value) {
        if (Objects.isNull(overrides)) {
            overrides = new Properties();
        }
        this.overrides.setProperty(name, value);
        return this;
    }

    public {{ ProjectPrefix }}{{ ProjectSuffix }}Server start() {
        this.springApplication = new SpringApplication({{ ProjectPrefix }}{{ ProjectSuffix }}ServerConfig.class);
        if (Objects.nonNull(overrides)) {
            springApplication.addInitializers(applicationContext -> applicationContext.getEnvironment().getPropertySources().addFirst(new PropertiesPropertySource("overrides", overrides)));
        }
        this.context = springApplication.run(Objects.isNull(args)? Strings.EMPTY_ARRAY:args);
        return this;
    }

    public {{ ProjectPrefix }}{{ ProjectSuffix }}Server stop() {
        if (context != null) {
            context.close();
        }
        return this;
    }

    public int getGrpcPort() {
        Integer grpcPort = context.getBean(GRpcServerProperties.class).getPort();
        if (grpcPort == null) {
            throw new RuntimeException("gRPC not started!");
        }
        return grpcPort;
    }

}
