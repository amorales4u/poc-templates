package {{ root_package }}.server;

import {{ root_package }}.core.{{ ProjectPrefix }}{{ ProjectSuffix }}CoreConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
{% if kafka-event %}
import org.springframework.kafka.annotation.EnableKafka;
{% endif %}

{% if persistence == "MongoDB" %}
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
{% endif %}

@Configuration
@Import({{ ProjectPrefix }}{{ ProjectSuffix }}CoreConfig.class)
@ComponentScan(basePackages = "{{ root_package }}")
{% if kafka-event %}
@EnableKafka
{% endif %}

{% if persistence == "MongoDB" %}
@EnableMongoRepositories
{% endif %}

@SpringBootApplication
public class {{ ProjectPrefix }}{{ ProjectSuffix }}ServerConfig{
  
   public static void main(String ... args){
     {{ ProjectPrefix }}{{ ProjectSuffix }}Server server=new {{ ProjectPrefix }}{{ ProjectSuffix }}Server();
     server.withArguments(args).start();
   }
}
