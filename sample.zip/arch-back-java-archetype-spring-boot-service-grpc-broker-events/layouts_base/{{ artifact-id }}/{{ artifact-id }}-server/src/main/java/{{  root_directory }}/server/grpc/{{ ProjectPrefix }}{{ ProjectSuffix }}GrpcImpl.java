package {{ root_package }}.server.grpc;

import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;
import {{ root_package }}.core.{{ ProjectPrefix }}{{ ProjectSuffix }}Core;
import {{ root_package }}.grpc.*;
import {{ root_package }}.grpc.{{ ProjectPrefix }}{{ ProjectSuffix }}Grpc.{{ ProjectPrefix }}{{ ProjectSuffix }}ImplBase;

@GRpcService
public class {{ ProjectPrefix }}{{ ProjectSuffix }}GrpcImpl extends {{ ProjectPrefix }}{{ ProjectSuffix }}Grpc.{{ ProjectPrefix }}{{ ProjectSuffix }}ImplBase {

    private final {{ ProjectPrefix }}{{ ProjectSuffix }}Core service;

    public {{ ProjectPrefix }}{{ ProjectSuffix }}GrpcImpl({{ ProjectPrefix }}{{ ProjectSuffix }}Core service) {
        this.service = service;
    }

    @Override
    public void create{{ ProjectPrefix }}({{ ProjectPrefix }}Dto request, StreamObserver<Create{{ ProjectPrefix }}Response> responseObserver) {
        Create{{ ProjectPrefix }}Response {{ projectPrefix }}Response = service.create{{ ProjectPrefix }}(request);
        responseObserver.onNext({{ projectPrefix }}Response);
        responseObserver.onCompleted();
    }

    @Override
    public void get{{ ProjectPrefix }}(Get{{ ProjectPrefix }}Request request, StreamObserver<Get{{ ProjectPrefix }}Response> responseObserver) {
        Get{{ ProjectPrefix }}Response response = service.get{{ ProjectPrefix }}(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void get{{ ProjectPrefix | pluralize }}(Get{{ ProjectPrefix | pluralize }}Request request, StreamObserver<Get{{ ProjectPrefix | pluralize }}Response> responseObserver) {
        Get{{ ProjectPrefix | pluralize }}Response response = service.get{{ ProjectPrefix | pluralize }}(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void update{{ ProjectPrefix }}({{ ProjectPrefix }}Dto request, StreamObserver<Update{{ ProjectPrefix }}Response> responseObserver) {
        Update{{ ProjectPrefix }}Response response = service.update{{ ProjectPrefix }}(request);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
