package {{ root_package }}.server.grpc;

import com.google.protobuf.StringValue;
import {{ root_package }}.core.{{ ProjectPrefix }}{{ ProjectSuffix }}Core;
import {{ root_package }}.grpc.*;
import {{ root_package }}.server.{{ ProjectPrefix }}{{ ProjectSuffix }}Server;
import {{ root_package }}.server.{{ ProjectPrefix }}{{ ProjectSuffix }}ServerConfig;
import {{ root_package }}.server.controller.RootController;

import io.grpc.stub.StreamObserver;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

class {{ ProjectPrefix }}{{ ProjectSuffix }}GrpcImplTest {

    @MockBean
    private static {{ ProjectPrefix }}{{ ProjectSuffix }}Core serviceCore;
    private static {{ ProjectPrefix }}{{ ProjectSuffix }}GrpcImpl service;


    private static StreamObserver<Create{{ ProjectPrefix }}Response> createStreamObserver;
    private static StreamObserver<Get{{ ProjectPrefix }}Response> getStreamObserver;
    private static StreamObserver<Get{{ ProjectPrefix }}sResponse> getSStreamObserver;
    private static StreamObserver<Update{{ ProjectPrefix }}Response> update{{ ProjectPrefix }}Observer;

    private static Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}Response;
    private static Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}Response;
    private static Get{{ ProjectPrefix }}sResponse get{{ ProjectPrefix }}sResponse;
    private static Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}Response;


    private static final UUID gUUID = UUID.randomUUID();


    @BeforeAll
    public static void setUp(){
        serviceCore = Mockito.mock({{ ProjectPrefix }}{{ ProjectSuffix }}Core.class);
        service = new {{ ProjectPrefix }}{{ ProjectSuffix }}GrpcImpl(serviceCore);

        {{ ProjectPrefix }}Dto accountDtoRes = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .setId(StringValue.of(gUUID.toString()))
                .build();

        create{{ ProjectPrefix }}Response = Create{{ ProjectPrefix }}Response.newBuilder()
                .set{{ ProjectPrefix }}(accountDtoRes)
                .build();

        update{{ ProjectPrefix }}Response = Update{{ ProjectPrefix }}Response.newBuilder()
                .build();


        get{{ ProjectPrefix }}Response = Get{{ ProjectPrefix }}Response.newBuilder()
                .set{{ ProjectPrefix }}(accountDtoRes)
                .build();

        get{{ ProjectPrefix }}sResponse = Get{{ ProjectPrefix }}sResponse.newBuilder()
                .build();

        createStreamObserver = new StreamObserver<>() {
            @Override
            public void onNext(Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}Response) {
            }
            @Override
            public void onError(Throwable throwable) {
            }
            @Override
            public void onCompleted() {
            }
        };

        getStreamObserver= new StreamObserver<>() {
            @Override
            public void onNext(Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}Response) {
            }
            @Override
            public void onError(Throwable throwable) {
            }
            @Override
            public void onCompleted() {
            }
        };

        getSStreamObserver = new StreamObserver<>() {
            @Override
            public void onNext(Get{{ ProjectPrefix }}sResponse get{{ ProjectPrefix }}sResponse) {
            }

            @Override
            public void onError(Throwable throwable) {
            }

            @Override
            public void onCompleted() {
            }
        };

        update{{ ProjectPrefix }}Observer = new StreamObserver<>() {
            @Override
            public void onNext(Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}Response) {
            }
            @Override
            public void onError(Throwable throwable) {
            }
            @Override
            public void onCompleted() {
            }
        };



    }

    @Test
    void test_constructors() {
        {{ ProjectPrefix }}{{ ProjectSuffix }}Server accountServiceServer = new {{ ProjectPrefix }}{{ ProjectSuffix }}Server();
        assertThat(accountServiceServer).isNotNull();

        {{ ProjectPrefix }}{{ ProjectSuffix }}ServerConfig accountServiceServerConfig = new {{ ProjectPrefix }}{{ ProjectSuffix }}ServerConfig();
        assertThat(accountServiceServerConfig).isNotNull();

        RootController rootController = new RootController();
        assertThat(rootController).isNotNull();
        assertThat(rootController.root()).isNotNull();
    }

    @Test
    void test_create{{ ProjectPrefix }}() {

        {{ ProjectPrefix }}Dto accountDto = {{ ProjectPrefix }}Dto.newBuilder()
                .setName("{{ ProjectPrefix }}1")
                .build();

        Mockito.when(serviceCore.create{{ ProjectPrefix }}(Mockito.any()))
                .thenReturn(create{{ ProjectPrefix }}Response);

        service.create{{ ProjectPrefix }}(accountDto, createStreamObserver);
        assertTrue(true);
    }

    @Test
    void test_get{{ ProjectPrefix }}() {

        Get{{ ProjectPrefix }}Request get{{ ProjectPrefix }}Request = Get{{ ProjectPrefix }}Request.newBuilder()
                .setId(gUUID.toString())
                .build();

        Mockito.when(serviceCore.get{{ ProjectPrefix }}(Mockito.any()))
                .thenReturn(get{{ ProjectPrefix }}Response);

        service.get{{ ProjectPrefix }}(get{{ ProjectPrefix }}Request, getStreamObserver);
        assertTrue(true);
    }

    @Test
    void test_get{{ ProjectPrefix }}s() {
        Get{{ ProjectPrefix }}sRequest get{{ ProjectPrefix }}sRequest = Get{{ ProjectPrefix }}sRequest.newBuilder()
                .setStartPage(0)
                .setPageSize(10)
                .build();

        Mockito.when(serviceCore.get{{ ProjectPrefix }}s(Mockito.any()))
                .thenReturn(get{{ ProjectPrefix }}sResponse);

        service.get{{ ProjectPrefix }}s(get{{ ProjectPrefix }}sRequest, getSStreamObserver);
        assertTrue(true);
    }

    @Test
    void test_update{{ ProjectPrefix }}() {

        {{ ProjectPrefix }}Dto accountDto = {{ ProjectPrefix }}Dto.newBuilder()
                .setId(StringValue.of(gUUID.toString()))
                .setName("{{ ProjectPrefix }}2")
                .build();

        Mockito.when(serviceCore.update{{ ProjectPrefix }}(Mockito.any()))
                .thenReturn(update{{ ProjectPrefix }}Response);


        service.update{{ ProjectPrefix }}(accountDto, update{{ ProjectPrefix }}Observer);
        assertTrue(true);
    }
}