package {{ root_package }}.api;

import {{ root_package }}.grpc.*;


public interface {{ ProjectPrefix }}{{ ProjectSuffix }} {
    Create{{ ProjectPrefix }}Response create{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }});
    Get{{ ProjectPrefix | pluralize }}Response get{{ ProjectPrefix | pluralize }}(Get{{ ProjectPrefix | pluralize }}Request request);
    Get{{ ProjectPrefix }}Response get{{ ProjectPrefix }}(Get{{ ProjectPrefix }}Request request);
    Update{{ ProjectPrefix }}Response update{{ ProjectPrefix }}({{ ProjectPrefix }}Dto {{ projectPrefix }});
}

