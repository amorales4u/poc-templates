package {{root_package}}.persistence.entities;


import jakarta.persistence.*;
import java.util.UUID;
import java.time.Instant;

{% if persistence == 'MongoDB' %}
import org.springframework.data.mongodb.core.mapping.Document;

@Document("{{project_prefix}}")
public class {{ProjectPrefix}}Entity {
    @Id
    private UUID id;

    private String name;

    private Instant lastModifiedDate;

    private Instant createdDate;

    protected Short version;
{% elif persistence == 'Redis' %}
import org.springframework.data.redis.core.RedisHash;
@RedisHash("Employee")
public class Employee implements Serializable {

{% else %}
@Entity
@Table(name = "{{project_prefix}}")
public class {{ProjectPrefix}}Entity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private UUID id;

    @Column(name = "name")
    private String name;

    @Column(nullable = false, name = "modified")
    private Instant lastModifiedDate;

    @Column(nullable = false, name = "created")
    private Instant createdDate;

    @Version
    @Column(name = "version")
    protected Short version;
{% endif %}


    // Hibernate requires a default constructor
    public {{ProjectPrefix}}Entity() {}

    public {{ProjectPrefix}}Entity(String name) {
        this.name = name;
        defaultModifiedAndCreated();
    }

    public void defaultModifiedAndCreated(){
        final Instant now = Instant.now();
        this.createdDate=now;
        this.lastModifiedDate=now;
    }

    public {{ProjectPrefix}}Entity( UUID id,String name) {
        this.id=id;
        this.name = name;
        defaultModifiedAndCreated();
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Short getVersion() {
        return version;
    }

    public void setVersion(final Short version) {
        this.version = version;
    }


    public Instant getModifiedAt() {
        return lastModifiedDate;
    }


    public void setModifiedAt(final Instant instant) {
        this.lastModifiedDate = instant;
    }

    public Instant getCreatedAt() {
        return createdDate;
    }

    public void setCreatedAt(final Instant instant) {
        this.createdDate = instant;
    }
}
