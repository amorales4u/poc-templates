package {{root_package}}.persistence.repositories;

import {{root_package}}.persistence.entities.{{ ProjectPrefix }}Entity;

{% if persistence == 'MongoDB' %}
import org.springframework.data.mongodb.repository.MongoRepository;
{% else %}
import org.springframework.data.jpa.repository.JpaRepository;
{% endif %}

import org.springframework.stereotype.Repository;

import java.util.UUID;

{% if persistence == 'MongoDB' %}
public interface {{ProjectPrefix}}Repository extends MongoRepository<{{ ProjectPrefix }}Entity, UUID> {
{% else %}
public interface {{ProjectPrefix}}Repository extends JpaRepository<{{ ProjectPrefix }}Entity, UUID> {
{% endif %}


}
