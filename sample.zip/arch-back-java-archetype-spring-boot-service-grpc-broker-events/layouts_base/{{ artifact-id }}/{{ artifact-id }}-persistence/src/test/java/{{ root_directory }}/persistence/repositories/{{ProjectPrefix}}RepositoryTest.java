package {{root_package}}.persistence.repositories;

import {{root_package}}.persistence.entities.{{ProjectPrefix}}Entity;
import {{root_package}}.persistence.{{ ProjectPrefix }}{{ ProjectSuffix }}PersistenceConfig;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


class {{ProjectPrefix}}RepositoryTest {
    @MockBean
    private static {{ProjectPrefix}}Repository g{{ProjectPrefix}}Repository;

    private static {{ProjectPrefix}}Entity g{{ProjectPrefix}}Entity;


    @BeforeAll
    static void setUp(){
        g{{ProjectPrefix}}Repository = Mockito.mock({{ProjectPrefix}}Repository.class);

        g{{ProjectPrefix}}Entity = new {{ProjectPrefix}}Entity();
        g{{ProjectPrefix}}Entity.setName("{{ProjectPrefix}}1");
        g{{ProjectPrefix}}Entity.setId( UUID.randomUUID());
        g{{ProjectPrefix}}Entity.setCreatedAt(Instant.now());
        g{{ProjectPrefix}}Entity.setVersion((short)1);
        g{{ProjectPrefix}}Entity.setModifiedAt(Instant.now());
    }

    @Test
    void test_constructors(){

        {{ProjectPrefix}}Entity v{{ProjectPrefix}}1 = new {{ProjectPrefix}}Entity();
        assertThat(v{{ProjectPrefix}}1).isNotNull();

        {{ProjectPrefix}}Entity v{{ProjectPrefix}}2 = new {{ProjectPrefix}}Entity("{{ProjectPrefix}}1");
        assertThat(v{{ProjectPrefix}}2).isNotNull();

        {{ProjectPrefix}}Entity v{{ProjectPrefix}}5 = new {{ProjectPrefix}}Entity(UUID.randomUUID(),"{{ProjectPrefix}}1");
        assertThat(v{{ProjectPrefix}}5).isNotNull();

        {{ ProjectPrefix }}{{ ProjectSuffix }}PersistenceConfig v{{ProjectPrefix}}ServicePersistenceConfig = new {{ ProjectPrefix }}{{ ProjectSuffix }}PersistenceConfig();
        assertThat(v{{ProjectPrefix}}ServicePersistenceConfig).isNotNull();
    }



    @Test
    void test_create{{ProjectPrefix}}(){

        {{ProjectPrefix}}Entity v{{ProjectPrefix}} = new {{ProjectPrefix}}Entity("{{ProjectPrefix}}1");



        Mockito.when(g{{ProjectPrefix}}Repository.save(Mockito.any()))
                .thenReturn(g{{ProjectPrefix}}Entity);

        v{{ProjectPrefix}} = g{{ProjectPrefix}}Repository.save(v{{ProjectPrefix}});

        assertThat(v{{ProjectPrefix}}.getId()).isNotNull();

    }


    @Test
    void test_get{{ProjectPrefix}}ById(){

        UUID uuid = UUID.randomUUID();

        Mockito.when(g{{ProjectPrefix}}Repository.findById(uuid))
                .thenReturn(Optional.of(g{{ProjectPrefix}}Entity));

        Optional<{{ProjectPrefix}}Entity> op{{ProjectPrefix}} = g{{ProjectPrefix}}Repository.findById(uuid);

        {{ProjectPrefix}}Entity v{{ProjectPrefix}} = op{{ProjectPrefix}}.orElseThrow();

        assertThat(v{{ProjectPrefix}}.getId()).isNotNull();

        assertThat(v{{ProjectPrefix}}.getId()).isNotNull();
        assertThat(v{{ProjectPrefix}}.getName()).isEqualTo("{{ProjectPrefix}}1");
        assertThat(v{{ProjectPrefix}}.getCreatedAt()).isNotNull();
        assertThat(v{{ProjectPrefix}}.getVersion()).isEqualTo((short)1);
        assertThat(v{{ProjectPrefix}}.getModifiedAt()).isNotNull();

    }


}