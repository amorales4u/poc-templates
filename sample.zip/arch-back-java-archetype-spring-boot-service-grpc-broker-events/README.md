# arch-back-java-archetype-spring-boot-service-grpc-broker-events

## Arquetipo basado en gRPC-Rest + Kafka o RabbitMQ
Este arquetipo esta basado en [SpringBoot](https://spring.io/projects/spring-boot) framework y usa [Maven](https://maven.apache.org/)
para crear un proyecto nuevo.

Este template provee la posibilidad de conectarse a Brokers Kafka y RabbitMQ.
En ellos puede crear los modulos para Producir o Consumir eventos.

Cuando un proyecto incluye Productor y consumidor del mismo "topico" o "Cola" no lanza el mensaje hacia el Broker.

## Guia de uso

* [Introduction](docs/001-introduction.md)
* [Preparacion de Ambiente](docs/010-preparacion-ambiente.md)
* [Archetect](docs/020-archetect.md)
* [Crear proyectos Kafka](docs/030-create-kafka-project.md)
* [Crear proyectos RabbitMQ](docs/040-create-rabbitmq-project.md)
* [General Testing](docs/050-general-testing.md)
* [Problemas Comunes al generar proyectos con Archetect](docs/060-commons-problems.md)

[Diagrama de Arquitectura](docs/arquitectura.drawio.png)

## Que sigue?
Crear Integration Test con TestContainers para Schema Registry, por el momento no
hay un TestContainer para Schema Registry, las pruebas podrian solo incluir TesContainer con Kafka.

## Dudas y contribuciones
#Las contibuciones son bienvenidas y las dudas las platicamos juntos [project planning board](https://gitlab.com/nirvana4/platform/archetypes/archetype-java-service-spring-boot/-/boards)
