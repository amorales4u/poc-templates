package {{ root_package }}.event.producer;

import {{ group-prefix }}.{{ namespace }}.model.avro.{{ ProjectPrefix }}Model;
import com.palo.it.event.kafka.producer.EventProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.kafka.support.SendResult;

@Service
public class {{ ProjectPrefix }}Producer extends EventProducer<{{ ProjectPrefix }}Model,SendResult<String,{{ ProjectPrefix }}Model>> {

    private final static Logger log = LoggerFactory.getLogger({{ ProjectPrefix }}Producer.class);

    @Autowired
    public {{ ProjectPrefix }}Producer(KafkaTemplate<String, {{ ProjectPrefix }}Model> kafkaTemplate) {
        super(kafkaTemplate);
        log.info("Start My Kafka {{ ProjectPrefix }} Producer with template {}", kafkaTemplate);
    }


    @Override
    public void onSendSuccess(SendResult<String, {{ ProjectPrefix }}Model> result) {
        log.info("Sent message=[{}] with offset=[{}]", result.toString(), result.getRecordMetadata()
                .offset());
    }

    public void onSendError(SendResult<String, {{ ProjectPrefix }}Model> result, Throwable ex) {
        log.info("Unable to send message=[{}] due to : {}", result, ex.getMessage());
    }
}
