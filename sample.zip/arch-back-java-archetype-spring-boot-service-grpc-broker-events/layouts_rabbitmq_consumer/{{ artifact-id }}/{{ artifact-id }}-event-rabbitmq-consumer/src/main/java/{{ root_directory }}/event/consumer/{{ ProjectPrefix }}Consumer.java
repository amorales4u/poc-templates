package {{ root_package }}.event.consumer;

import {{ root_package }}.api.{{ ProjectPrefix }}{{ ProjectSuffix }};
import {{ group-prefix }}.{{ namespace }}.model.avro.{{ ProjectPrefix }}Model;
import com.palo.it.event.rabbitmq.consumer.EventConsumer;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;


@Service
public class {{ ProjectPrefix }}Consumer extends EventConsumer<{{ ProjectPrefix }}Model> {

    {{ ProjectPrefix }}{{ ProjectSuffix }} service;

    private final static Logger log = LoggerFactory.getLogger({{ ProjectPrefix }}Consumer.class);

    @Override
    public void consume({{ ProjectPrefix }}Model message) {
        log.info("Message received from RabbitMQ: {}", message);
    }

}
