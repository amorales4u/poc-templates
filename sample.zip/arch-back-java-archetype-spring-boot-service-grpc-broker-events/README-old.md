# archetype-spring-boot-service-grpc

## What's Inside
This archetype is based on the [SpringBoot](https://spring.io/projects/spring-boot) framework and uses [Maven](https://maven.apache.org/)
as its build system.

Este template provee la polibilidad de conectarse a Brokers Kafka y RabbitMQ.
En ellos puede crear los modulos para Producir o Consumir.
* Cuando un proyecto incluye Productor y consumidor del mismo "topico" o "Cola" no lanza el mensaje hacia el Broker.

1. [Introduction](docs/001-introduction.md)

   Antes de iniciar es necesario instalar la imagen de Kafka y Schema Registry:

docker-compose.yml

```yaml
version: '2.1'
services:

  zookeeper:
    image: confluentinc/cp-zookeeper:5.1.2
    ports:
      - "2181:2181"
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181

  # reachable on 9092 from the host and on 29092 from inside docker compose
  kafka:
    image: confluentinc/cp-enterprise-kafka:5.1.2
    depends_on:
      - zookeeper
    ports:
      - '9092:9092'
    expose:
      - '29092'
    environment:
      KAFKA_ZOOKEEPER_CONNECT: 'zookeeper:2181'
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
      KAFKA_INTER_BROKER_LISTENER_NAME: PLAINTEXT
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092,PLAINTEXT_HOST://localhost:9092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: '1'
      KAFKA_MIN_INSYNC_REPLICAS: '1'
      KAFKA_SCHEMA_REGISTRY_URL: "schema-registry:8081"

  init-kafka:
    image: confluentinc/cp-kafka:5.1.2
    depends_on:
      - kafka
    entrypoint: [ '/bin/sh', '-c' ]
    command: |
      "
      # blocks until kafka is reachable
      kafka-topics --bootstrap-server kafka:29092 --list

      echo -e 'Creating kafka topics'
      kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic my-topic-1 --replication-factor 1 --partitions 1
      kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists --topic my-topic-2 --replication-factor 1 --partitions 1

      echo -e 'Successfully created the following topics:'
      kafka-topics --bootstrap-server kafka:29092 --list
      "
  schema-registry:
    image: confluentinc/cp-schema-registry:5.1.2
    restart: always
    hostname: schema-registry
    container_name: schema-registry
    depends_on:
      - zookeeper
    ports:
      - "8081:8081"
    environment:
      SCHEMA_REGISTRY_HOST_NAME: schema-registry
      SCHEMA_REGISTRY_KAFKASTORE_CONNECTION_URL: 'zookeeper:2181'
      SCHEMA_REGISTRY_LISTENERS: http://0.0.0.0:8081
      
```

y tambien instalr RabbitMQ:

docker-compose.yml

```yaml
version: "3.2"
services:
  rabbitmq:
    image: rabbitmq:3-management-alpine
    container_name: 'rabbitmq'
    ports:
        - 5672:5672
        - 15672:15672
    volumes:
        - ~/.docker-conf/rabbitmq/data/:/var/lib/rabbitmq/
        - ~/.docker-conf/rabbitmq/log/:/var/log/rabbitmq
    networks:
        - rabbitmq_go_net

networks:
  rabbitmq_go_net:
    driver: bridge
```


Enseguida clonar e instalar las siguientes dependencias:

```shell

mkdir -p ~/dev/architecture/commons/libs/java/command-events

cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/archetect/customer-templates/femsa/b2b/parent-dependencies.git

cd parent-dependencies

git checkout HT-63/Integracion-de-kafka

mvn clean install

cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/common-events-kafka.git

cd common-events-kafka

mvn clean install

cd ~/dev/architecture/commons/libs/java/command-events

git clone https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/common-events-rabbitmq.git

cd common-events-rabbitmq

mvn clean install

cd ~/

```

Para cuestion de prueba basica, puede generar el proyecto Consumer o Producer ya sea para Kafka o RabbitMQ, Ejemplos:

```shell

# # # # # # # # # # # # # # 
# Creating Kafka services
# # # # # # # # # # # # # # 

mkdir -p ~/dev/demo-events/
cd ~/dev/demo-events/
rm -r contract-service-consumer
# Create consumer service named Contract and Set range ports to 9010:
archetect --headless --answer-file=kfk-consumer.yaml render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/contract-service-consumer/
mvn clean install
cd ~/dev/demo-events/contract-service-consumer/contract-service-consumer-server
mvn spring-boot:run

# Create producer service named Contract and Set range ports to 9020:
cd ~/dev/demo-events/
rm -r contract-service-producer
archetect --headless --answer-file=kfk-producer.yaml render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/contract-service-producer/
mvn clean install
cd ~/dev/demo-events/contract-service-producer/contract-service-producer-server
mvn spring-boot:run

# Test with cURL

curl --request PUT \
  --url http://localhost:9021/ \
  --header 'Content-Type: application/json' \
  --data '{
  "message": "The first Kafka sent Message"
}'

# or test in PowerShell

$headers=@{}
$headers.Add("Content-Type", "application/json")
$response = Invoke-RestMethod -Uri 'http://localhost:9021/' -Method PUT -Headers $headers -ContentType 'application/json' -Body '{
  "message": "The first Kafka sent Message"
}'

```

```shell

# # # # # # # # # # # # # # 
# CreatingRabbitMQ services
# # # # # # # # # # # # # # 

mkdir -p ~/dev/demo-events/
cd ~/dev/demo-events/
rm -r account-service-consumer
# Create consumer service named Account and Set range ports to 9030:
archetect --headless --answer-file=rm-consumer.yaml render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/account-service-consumer/
mvn clean install
cd ~/dev/demo-events/account-service-consumer/account-service-consumer-server
mvn spring-boot:run

# Create producer service named Contract and Set range ports to 9040:
cd ~/dev/demo-events/
rm -r account-service-producer
archetect --headless --answer-file=rm-producer.yaml render https://gitlab.palo-it.net/hive-tech/architecture/commons/libs/java/commands-events/arch-back-java-archetype-spring-boot-service-grpc-broker-events.git

cd ~/dev/demo-events/account-service-producer/
mvn clean install
cd ~/dev/demo-events/account-service-producer/account-service-producer-server
mvn spring-boot:run



curl --request PUT \
  --url http://localhost:9041/ \
  --header 'Content-Type: application/json' \
  --data '{
  "message": "The first RabbitMQ sent Message"
}'

# or test in PowerShell

$headers=@{}
$headers.Add("Content-Type", "application/json")
$response = Invoke-RestMethod -Uri 'http://localhost:9041/' -Method PUT -Headers $headers -ContentType 'application/json' -Body '{
  "message": "The first RabbitMQ sent Message"
}'


```


More Features include:
- Simple CRUD over [gRPC](https://grpc.io/)
  - `/EmployeeService/GetEmployees`
  - `/EmployeeService/GetEmployee`
  - `/EmployeeService/CreateEmployee`
  - `/EmployeeService/UpdateEmployee`
- Load tests using [k6](https://k6.io/) for both HTTP and gRPC calls
- Application configuration through property files, environment variables, and CLI arguments.
- Integration with [Tilt](https://tilt.dev/) to support local k8s development
- Out-of-the-box Postgres and [LocalStack](https://github.com/localstack/localstack) using [Test Containers](https://www.testcontainers.org/)


> To get started you can need installed [Confluence](
https://paloit.atlassian.net/wiki/spaces/PIK/pages/1977352193/Archetect+code+generator)



## Prompts
When rendering the archetype, you'll be prompted for the following values:

| Property                         | Description                                                                                                  | Example                                      |
|----------------------------------|--------------------------------------------------------------------------------------------------------------|----------------------------------------------|
| `Project`                        | General name that represents the service domain that is used to set the entity, service, and RPC stub names. | Employee                                     |
| `Project Type`                   | Used in conjunction with `project` to set package names.                                                     | Service                                      | 
| `GroupId Prefix`                 | Used in conjunction with `project` to set package names.                                                     | com.palo.it                                  |
| `Name Space`                     | Domain / Kubernetes Namespace.                                                                               | service                                      |
| `Persistence Engine`             | Set the RDBMS to use ( PostgreSQL, MySQL, H2, MongoDB ).                                                     | H2                                           |
| `Event Module`                   | Set if do you what a Event project type ( Kafka or RabbitMQ, Producer or Consumer ).                         | No                                           |
| `Service Port Range Start`       | Sets the port used for gRPC traffic                                                                          | 9010                                         |
| `HTTP Management Port`           | Sets the port used to monitor the application over HTTP                                                      | {{ service-port + 1 }}                       |
| `HTTP server Port`               | Sets the port used to set server HTTP port                                                                   | {{ service-port + 1 }}                       |
| `Developer Database Port`        | Sets the port used to connect to Database selected                                                           | {{ service-port + 2 }}                       |
| `Remote Debug Port`              | Sets the port used to debug application over HTTP                                                            | {{ service-port + 9 }}                       |
| `Jfrog repository url`           | Sets the Jfrog repository URL                                                                                | https://nexus.digitalb2b.dev                 |
| `Jfrog repository relaese name`  | Sets the Jfrog repository release name                                                                       | b2b-libs-release                             |
| `Jfrog repository snapshot name` | Sets the Jfrog repository snapshot name                                                                      | b2b-libs-snapshot                            |
| `Url docker registry`            | Sets URL Docker registry                                                                                     | 690003025816.dkr.ecr.us-east-1.amazonaws.com |
| `sonar url`                      | Sets URL Sonar                                                                                               | https://sonarqube.digitalb2b.dev             |


For a list of all derived properties and examples of the property relationships, see [archetype.yml](./archetype.yml).


5) Goto generated directory **employee-service**:
 
```shell
cd .\employee-service\
```

6) Compile with **maven**:

```shell
mvn clean install
```


## How run project 

```shell
mvn -f employee-service-server spring-boot:run
```

## Test project

**httpYac** provides a system to provide a simple way to create, execute, and store information about HTTP requests even to gRPC calls.

Install in Visual Studio Code, you can se a complete guide in [httpYac](https://httpyac.github.io/guide/) 

![httpYac.png](httpYac.png)


open test-client.http for test your http and gRPC new Services.
```http request
###

@http_host=http://localhost:{{ management-port }}
@gRPC_host=localhost:{{ service-port }}
@gRPC_proto_file=./{{ artifact-id }}-grpc/src/main/proto/{{ project-prefix }}-{{ project-suffix}}.proto

@project_name={{ project-prefix }}
@project_service_name={{ project-prefix }}-{{ project-suffix}}

###
GET {{http_host}}/actuator

###

GET {{http_host}}/actuator/health

###

GET {{http_host}}/actuator/info

###

proto < {{gRPC_proto_file}}
GRPC {{gRPC_host}}/{{project_service_name}}/Get{{ ProjectPrefix | pluralize }}
{ 
    "startPage": 0,
    "pageSize": 10

}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Get{{project_name}}
{ 
    "id": "893ccc03-3c47-492d-b388-a21d642c063f"
}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Update{{project_name}}
{ 
    "id": {
        "value":"893ccc03-3c47-492d-b388-a21d642c063f"
    },
    "name": "John Doe"

}

###

proto < {{gRPC_proto_file}}

GRPC {{gRPC_host}}/{{project_service_name}}/Create{{project_name}}
{
    "employee": {
        "id": {
            "value": "893ccc03-3c47-492d-b388-a21d642c063f"
        },
        "name": "Juan Perez"
    }
}

###

```


## What's Next
#For a list of feature to be developed soon, check out the **Planning::Backlog** on the [project planning board](https://gitlab.com/nirvana4/platform/archetypes/archetype-java-service-spring-boot/-/boards).

## Common issues at create projects with archetect

At create/render project with **archetect** the must common error show as:`Rendering IO Error: The system cannot find the path specified. (os error 3)`
, this error caused by a nonexistent variable, check de Jinja tags with the generated variables in archetype.yml

When you render a project and have that error, the problem is in the last file or directory rendered.

For correct errors en templates you need:

1) Cloning the template project:

```shell
git clone https://gitlab.palo-it.net/hive-tech/architecture/archetect/customer-templates/femsa/b2b/arch-back-java-archetype-spring-boot-service-grpc.git
```

2) archetect render in local mode :
```shell
archetect render ./arch-back-java-archetype-spring-boot-service-grpc
```
or
render with a high verbosity label:
```shell
archetect render -vvv ./arch-back-java-archetype-spring-boot-service-grpc
```

with -vvv  you see a log with more information, and archetect show log like this:

```shell
Project Name: User
Project Type: [DomainGateway]
GroupId Prefix: [com.b2b] com.palo.it
Domain / Kubernetes Namespace: [user]
Service Port Range Start: [8080]
archetect: Setting variable answer "management-port"="{{ service-port + 1 }}"
archetect: Setting variable answer "debug-port"="{{ service-port + 9 }}"
Integrate default service? [n]
Jfrog repository url: [https://nexus.digitalb2b.dev]
Jfrog repository relaese name: [b2b-libs-release]
Jfrog repository snapshot name: [b2b-libs-snapshot]
Url docker registry: [690003025816.dkr.ecr.us-east-1.amazonaws.com]
sonar url: [https://sonarqube.digitalb2b.dev]
Url docker registry image: [690003025816.dkr.ecr.us-east-1.amazonaws.com/User-gateway:1.$BITBUCKET_BUILD_NUMBER]
archetect: Setting variable answer "ProjectTitle"="{{ project | title_case }} {{ suffix | title_case }}"
archetect: Setting variable answer "ProjectPrefix"="{{ project | pascal_case }}"
archetect: Setting variable answer "projectPrefix"="{{ project | camel_case }}"
archetect: Setting variable answer "project_prefix"="{{ project | snake_case }}"
archetect: Setting variable answer "project-prefix"="{{ project | train_case }}"
archetect: Setting variable answer "PROJECT_PREFIX"="{{ project | constant_case }}"
archetect: Setting variable answer "ProjectSuffix"="{{ suffix | pascal_case }}"
archetect: Setting variable answer "project_suffix"="{{ suffix | snake_case }}"
archetect: Setting variable answer "project-suffix"="{{ suffix | train_case }}"
archetect: Setting variable answer "root_package"="{{ group-prefix }}.{{ project | package_case }}.{{ suffix | package_case }}"
archetect: Setting variable answer "root_directory"="{{ root_package | package_to_directory }}"
archetect: Setting variable answer "artifact_id"="{{ project_prefix }}_{{ project_suffix }}"
archetect: Setting variable answer "artifact-id"="{{ project-prefix }}-{{ project-suffix }}"
archetect: Setting variable answer "client-artifact-id"="{{ project-prefix }}-service"
archetect: Setting variable answer "client_root_package"="{{ group-prefix }}.{{ project | package_case }}.service"
archetect: Setting variable answer "group-id"="{{ group-prefix }}.{{ artifact-id }}"
archetect: Setting variable answer "property-prefix"="{{ artifact-id }}"
archetect: Rendering   ".\\user-domain-gateway"
archetect: Preserving  ".\\user-domain-gateway\\.gitignore"
archetect: Preserving  ".\\user-domain-gateway\\bitbucket-pipelines.yml"
archetect: Preserving  ".\\user-domain-gateway\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\support"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\support\\Converter.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCore.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\main\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreConfig.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\support"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\support\\ConverterTest.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreConfigTest.java"
archetect: Preserving  ".\\user-domain-gateway\\user-domain-gateway-core\\src\\test\\java\\com/palo/it/user/domain/gateway\\core\\UserDomainGatewayCoreTest.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources\\schema"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-graphql\\src\\main\\resources\\schema\\schema.graphqls"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\pom.xml"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\util"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\util\\Projections.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayBaseIT.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayCoreTest.java"
archetect: Rendering   ".\\user-domain-gateway\\user-domain-gateway-integration-test\\src\\test\\com.palo.it.user.domain.gateway\\integration\\test\\UserDomainGatewayIntegrationTestConfig.java"
archetect: Rendering IO Error: The system cannot find the path specified. (os error 3)
```

3) Check last file/directory.
4) Check Jinja tags are defined in archetype.xml
5) Try render again.


If you find errors, have ideas or contributions for this template you are welcome to improve this project :-)
Checkout open tickets on the [project planning board](https://gitlab.com/nirvana4/platform/archetypes/archetype-java-service-spring-boot/-/boards)



## Questions and Contributions
#Contributions welcome! Checkout open tickets on the [project planning board](https://gitlab.com/nirvana4/platform/archetypes/archetype-java-service-spring-boot/-/boards)
#for ideas. To suggestion an enhancement or file a bug, create an issue under the **Open** list. Additional questions
#are welcome in the [#plaform](https://nirvana-ltw6429.slack.com/archives/C021FEG1T60) slack channel.
