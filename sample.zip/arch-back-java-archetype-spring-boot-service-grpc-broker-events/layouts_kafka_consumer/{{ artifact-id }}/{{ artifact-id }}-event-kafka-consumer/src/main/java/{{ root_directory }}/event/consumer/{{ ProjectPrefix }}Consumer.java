package {{ root_package }}.event.consumer;

import {{ root_package }}.api.{{ ProjectPrefix }}{{ ProjectSuffix }};
import {{ group-prefix }}.{{ namespace }}.model.avro.{{ ProjectPrefix }}Model;
import com.palo.it.event.kafka.consumer.EventConsumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class {{ ProjectPrefix }}Consumer extends EventConsumer<ConsumerRecord<String, {{ ProjectPrefix }}Model>> {
    {{ ProjectPrefix }}{{ ProjectSuffix }} service;

    private final static Logger log = LoggerFactory.getLogger({{ ProjectPrefix }}Consumer.class);

    public void consume(ConsumerRecord<String, {{ ProjectPrefix }}Model> record) {
        log.info(String.format("{{ ProjectPrefix }}Model received -> %s", record.value()));
    }

}
